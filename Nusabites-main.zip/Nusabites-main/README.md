
  # Nusa Bites Website UI

  This is a code bundle for Nusa Bites Website UI. The original project is available at https://www.figma.com/design/ipCVNPi3EEDO9ZKJyFO1u7/Nusa-Bites-Website-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  